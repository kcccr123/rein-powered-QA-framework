using UnityEngine;

// Measures the observed and physically traversable part of a proposed waypoint leg.
internal sealed class QaWaypointClearance
{
    public const int Budget = 64;
    public int Queries { get; private set; }
    public float Radius => body.Radius;
    public bool OriginBlocked { get; private set; }
    private ModelSensorGrid grid;
    private CharacterController actor;
    private QaNavigationCapsule body;
    private bool originChecked;

    public void Begin(ModelSensorGrid knowledge, CharacterController character)
    {
        grid = knowledge;
        actor = character;
        body = new QaNavigationCapsule(actor);
        Queries = 0;
        originChecked = OriginBlocked = false;
    }

    // Visit every crossed cell in the same order as the sensor ray journal.
    // A wall-hit cell can contain free space; the full capsule decides its clearance.
    private float ObservedLength(Vector3 direction, float distance)
    {
        Vector3 origin = body.Position;
        Vector2Int cell = ModelSensorGrid.WorldToCell(origin);
        int dx = System.Math.Sign(direction.x), dz = System.Math.Sign(direction.z);
        float size = ModelSensorGrid.CellSize;
        float x = float.PositiveInfinity, z = float.PositiveInfinity;
        if (dx != 0) x = ((cell.x + (dx > 0 ? 1 : 0)) * size - origin.x) / direction.x;
        if (dz != 0) z = ((cell.y + (dz > 0 ? 1 : 0)) * size - origin.z) / direction.z;
        float stepX = dx == 0 ? float.PositiveInfinity : size / Mathf.Abs(direction.x);
        float stepZ = dz == 0 ? float.PositiveInfinity : size / Mathf.Abs(direction.z);
        float entered = 0f;
        while (entered <= distance)
        {
            if (!grid.ReadCell(cell).Observed) return Mathf.Max(0f, entered - 0.002f);
            entered = Mathf.Min(x, z);
            if (x <= entered) { cell.x += dx; x += stepX; }
            if (z <= entered) { cell.y += dz; z += stepZ; }
        }
        return distance;
    }

    // Two endpoint overlaps and a full sweep. A clipped ray ends before first contact.
    public bool TryLeg(Vector3 requested, bool allowShorter, out Vector3 point)
    {
        Vector3 origin = body.Position;
        requested.y = origin.y;
        point = origin;
        Vector3 delta = requested - origin;
        float length = delta.magnitude;
        if (length < 0.025f || Queries + 3 > Budget) return false;
        Vector3 direction = delta / length;
        float clear = ObservedLength(direction, length);
        if (clear < length && !allowShorter || clear < 0.025f) return false;
        if (!originChecked)
        {
            originChecked = true;
            OriginBlocked = Overlaps(Vector3.zero);
        }
        if (OriginBlocked) return false;
        Queries++;
        foreach (RaycastHit hit in Physics.CapsuleCastAll(body.Bottom, body.Top, body.Radius,
            direction, clear, Physics.DefaultRaycastLayers, QueryTriggerInteraction.Ignore))
        {
            if (!Blocks(hit.collider)) continue;
            if (!allowShorter) return false;
            clear = Mathf.Min(clear, hit.distance - 0.04f);
        }
        if (clear < 0.025f || Overlaps(direction * clear)) return false;
        point = origin + direction * clear;
        return true;
    }

    private bool Overlaps(Vector3 shift)
    {
        Queries++;
        foreach (Collider hit in Physics.OverlapCapsule(body.Bottom + shift, body.Top + shift,
            body.Radius, Physics.DefaultRaycastLayers, QueryTriggerInteraction.Ignore))
            if (Blocks(hit)) return true;
        return false;
    }

    private bool Blocks(Collider hit)
    {
        if (hit.transform.IsChildOf(actor.transform)) return false;
        ModelSensorTarget wall = hit.GetComponentInParent<ModelSensorTarget>();
        if (wall != null && wall.HitId == QaObjectType.Wall) return true;
        if (hit.GetComponentInParent<DungeonDoor>() != null) return true;
        QaSemanticTarget target = hit.GetComponentInParent<QaSemanticTarget>();
        return target != null && target.blocksNavigation;
    }
}
