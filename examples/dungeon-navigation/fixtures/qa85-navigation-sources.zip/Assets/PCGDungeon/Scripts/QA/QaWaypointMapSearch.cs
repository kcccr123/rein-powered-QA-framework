using System;
using System.Collections.Generic;
using UnityEngine;

// Resumable search over previously observed floor. Only a live capsule check can publish a leg.
internal sealed class QaWaypointMapSearch
{
    public const int Budget = 256;
    public bool ForExit { get; }
    public bool Finished { get; private set; }
    public int LastExpansions { get; private set; }
    public readonly List<Vector3> Path = new List<Vector3>();
    private readonly ModelSensorGrid grid;
    private readonly Vector2Int start, preferredCell;
    private readonly Bounds exitBounds;
    private readonly float height;
    private readonly Func<Vector2Int, bool> excluded;
    private readonly Func<Vector3, bool> freshFrontier;
    private readonly Dictionary<Vector2Int, Vector2Int> parent = new Dictionary<Vector2Int, Vector2Int>();
    private readonly Dictionary<Vector2Int, int> cost = new Dictionary<Vector2Int, int>();
    private readonly SortedSet<Entry> open = new SortedSet<Entry>();
    private int sequence;
    private Vector2Int closest;
    private int closestDistance;
    private bool issuedPrefix;

    private readonly struct Entry : IComparable<Entry>
    {
        public readonly Vector2Int Cell;
        public readonly int Cost;
        private readonly int priority, sequence;
        public Entry(Vector2Int cell, int cost, int priority, int sequence)
        { Cell = cell; Cost = cost; this.priority = priority; this.sequence = sequence; }
        public int CompareTo(Entry other)
        {
            int order = priority.CompareTo(other.priority);
            if (order == 0) order = sequence.CompareTo(other.sequence);
            return order;
        }
    }

    public QaWaypointMapSearch(ModelSensorGrid grid, Vector3 origin, bool forExit, Bounds exitBounds, Vector2Int preferredCell,
        Func<Vector2Int, bool> excluded, Func<Vector3, bool> freshFrontier)
    {
        this.grid = grid;
        this.excluded = excluded;
        this.freshFrontier = freshFrontier;
        this.exitBounds = exitBounds;
        ForExit = forExit;
        start = ModelSensorGrid.WorldToCell(origin);
        this.preferredCell = preferredCell;
        closest = start; closestDistance = (preferredCell - start).sqrMagnitude;
        height = origin.y;
        cost[start] = 0;
        parent[start] = start;
        open.Add(new Entry(start, 0, 0, sequence++));
    }

    public void Advance()
    {
        LastExpansions = 0;
        while (open.Count > 0 && LastExpansions < Budget)
        {
            Entry entry = open.Min;
            open.Remove(entry);
            LastExpansions++;
            Vector2Int cell = entry.Cell;
            if (cost[cell] != entry.Cost) continue;
            int remaining = (cell - preferredCell).sqrMagnitude;
            if (remaining < closestDistance) { closest = cell; closestDistance = remaining; }
            Vector3 point = QaObservedRoutePlanner.Point(cell, height);
            if (cell != start && IsDestination(cell, point))
            {
                CopyPath(cell, Path);
                Finished = true;
                return;
            }
            for (int dz = -1; dz <= 1; dz++)
            for (int dx = -1; dx <= 1; dx++)
            {
                if (dx == 0 && dz == 0) continue;
                var next = cell + new Vector2Int(dx, dz);
                if (!OpenFloor(next)) continue;
                bool diagonal = dx != 0 && dz != 0;
                if (diagonal && (!OpenFloor(cell + new Vector2Int(dx, 0)) ||
                    !OpenFloor(cell + new Vector2Int(0, dz)))) continue;
                int nextCost = entry.Cost + (diagonal ? 14 : 10);
                if (cost.TryGetValue(next, out int old) && old <= nextCost) continue;
                cost[next] = nextCost;
                parent[next] = cell;
                // Aim across already mapped floor at the known opening. Another reachable frontier
                // encountered on the way still qualifies; an obstructed preferred cell cannot starve it.
                int x = Mathf.Abs(next.x - preferredCell.x), z = Mathf.Abs(next.y - preferredCell.y);
                int priority = nextCost + 10 * Mathf.Max(x, z) + 4 * Mathf.Min(x, z);
                open.Add(new Entry(next, nextCost, priority, sequence++));
            }
        }
        Finished = open.Count == 0;
    }

    public bool TryCopyPrefix(List<Vector3> destination)
    {
        // An expanded node has a connected path through observed floor. Issue at most one
        // provisional route per search, and only if it advances toward the actual destination.
        if (issuedPrefix || (closest - start).sqrMagnitude < 16 ||
            Vector2Int.Distance(start, preferredCell) - Mathf.Sqrt(closestDistance) < 2f) return false;
        issuedPrefix = true;
        CopyPath(closest, destination);
        return true;
    }

    private void CopyPath(Vector2Int end, List<Vector3> destination)
    {
        destination.Clear();
        for (Vector2Int p = end; p != start; p = parent[p])
            destination.Add(QaObservedRoutePlanner.Point(p, height));
        destination.Reverse();
    }

    private bool OpenFloor(Vector2Int cell)
    {
        ModelMapCell value = grid.ReadCell(cell);
        return value.Observed && !value.Wall && !excluded(cell);
    }

    private bool IsDestination(Vector2Int cell, Vector3 point)
    {
        if (ForExit)
        {
            Vector3 closest = exitBounds.ClosestPoint(point);
            return Mathf.Abs(closest.x - point.x) < 0.01f && Mathf.Abs(closest.z - point.z) < 0.01f;
        }
        bool frontier = !grid.ReadCell(cell + Vector2Int.right).Observed ||
            !grid.ReadCell(cell + Vector2Int.left).Observed || !grid.ReadCell(cell + Vector2Int.up).Observed ||
            !grid.ReadCell(cell + Vector2Int.down).Observed;
        return frontier && freshFrontier(point);
    }
}
