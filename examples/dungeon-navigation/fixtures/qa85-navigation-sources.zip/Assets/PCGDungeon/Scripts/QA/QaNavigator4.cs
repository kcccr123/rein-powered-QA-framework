using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>Retained, physically checked instructions from local sightlines and remembered routes.</summary>
public sealed class QaNavigator4 : IQaMeasuredNavigator
{
    private enum Leg { Explore, Exit, MapFrontier, MapExit, Retreat }
    private const float MinStep = 0.12f;
    private readonly QaWaypointClearance clearance = new QaWaypointClearance();
    private readonly List<Vector3> visits = new List<Vector3>();
    private readonly List<double> timings = new List<double>();
    private readonly HashSet<Vector2Int> rejected = new HashSet<Vector2Int>();
    private readonly HashSet<Vector2Int> frontiers = new HashSet<Vector2Int>();
    private readonly HashSet<Vector2Int> triedFrontiers = new HashSet<Vector2Int>();
    private readonly List<Vector3> mapRoute = new List<Vector3>();
    private readonly int[] visibleFrontiers = new int[ModelSensorPackage.RayCount];
    private readonly List<RayChoice> choices = new List<RayChoice>(ModelSensorPackage.RayCount);
    private readonly List<Vector3> stalledBearings = new List<Vector3>();
    private readonly List<Vector3> recentRepositions = new List<Vector3>();
    private ModelSensorPackage sensors;
    private ModelSensorGrid grid;
    private Vector3 position, heading, rejectionOrigin;
    private Bounds exitBounds;
    private bool knowsExit, usedRetreat, mapRouteIsPrefix, issuedPrefix, repositionNeeded;
    private Vector3 stallPosition, repositionOrigin;
    private QaWaypointMapSearch search;
    private int routeIndex, routeScan, choiceIndex, stalled, objectVersion, wallCount;
    private int rayExitJournal;
    private int discoveryCursor;
    private Vector2Int? approachedFrontier;
    private (int map, int objects, Vector2Int cell)? failedExit, failedFrontier, searchOrigin, choicesOrigin;
    private (int, int, Vector2Int) Here => (grid.NavigationVersion, objectVersion, ModelSensorGrid.WorldToCell(position));
    private float bestDistance, tolerance;
    private float lastRadius;
    private Leg leg, routePurpose;

    private readonly struct RayChoice
    {
        public readonly Vector3 Point;
        public readonly float Score;
        public readonly int Index;
        public readonly bool Visited;
        public RayChoice(Vector3 point, float score, int index, bool visited = false)
        { Point = point; Score = score; Index = index; Visited = visited; }
    }

    public bool HasWaypoint { get; private set; }
    public Vector3 Waypoint { get; private set; }
    public int WaypointVersion { get; private set; }
    public string Status { get; private set; } = "reset";
    public float MaxWaypointDistance { get; set; } = 10f;
    public bool HasGoal => HasWaypoint || search != null;
    public bool GoalIsExit => HasWaypoint ? IsExitLeg(leg) : search != null && search.ForExit;
    public Vector2Int GoalCell => ModelSensorGrid.WorldToCell(GoalIsExit ? exitBounds.center :
        Route.Count > 0 ? Route[Route.Count - 1] : Waypoint);
    public List<Vector3> Route { get; } = new List<Vector3>();
    public event Action<string> DiagnosticEvent;
    public int Replans { get; private set; }
    public int AbandonedGoals { get; private set; }
    public int PlannerBuilds { get; private set; }
    public int GoalSelections { get; private set; }
    public int RouteSearches { get; private set; }
    public int GoalSearchSkips { get; private set; }
    public int RefinementChecks { get; private set; }
    public int RefinedCells => 0;
    public int ExcludedCount => rejected.Count;
    public Vector3[] ExcludedFrontiers
    {
        get
        {
            var points = new List<Vector3>();
            foreach (Vector2Int cell in rejected) points.Add(QaObservedRoutePlanner.Point(cell, position.y));
            return points.ToArray();
        }
    }
    public QaObservedRoutePlanner PlannerSnapshot => null;
    public IReadOnlyList<double> Timings => timings;
    public double PlanningMilliseconds { get; private set; }
    public int MaxQueries { get; private set; }
    public int MaxExpansions { get; private set; }
    public int InterruptedWaypoints { get; private set; }
    public int WaypointArrivals { get; private set; }
    public int RecoveryAttempts { get; private set; }
    public int LastQueries => clearance.Queries;
    public int LastExpansions { get; private set; }
    public int CandidateCursor => choiceIndex;
    public string SearchPhase => search == null ? "idle" : search.ForExit ? "exit_route" : "frontier_route";
    private float Range => Mathf.Min(MaxWaypointDistance, sensors.RayRange);
    private static bool IsExitLeg(Leg value) => value == Leg.Exit || value == Leg.MapExit;
    private static float Distance(Vector3 a, Vector3 b) => QaNavigationCoordinator.Distance(a, b);

    public void Reset()
    {
        grid = null; search = null; visits.Clear(); timings.Clear(); rejected.Clear(); choices.Clear(); Route.Clear();
        frontiers.Clear(); triedFrontiers.Clear(); mapRoute.Clear(); discoveryCursor = 0; approachedFrontier = null;
        stalledBearings.Clear(); recentRepositions.Clear(); issuedPrefix = repositionNeeded = false;
        position = Waypoint = heading = Vector3.zero;
        HasWaypoint = knowsExit = usedRetreat = mapRouteIsPrefix = false;
        Status = "reset"; failedExit = failedFrontier = searchOrigin = choicesOrigin = null; objectVersion = -1;
        leg = Leg.Explore; lastRadius = 0f; wallCount = rayExitJournal = choiceIndex = routeIndex = routeScan = stalled = 0;
        WaypointVersion = Replans = AbandonedGoals = PlannerBuilds = GoalSelections = RouteSearches = 0;
        MaxQueries = MaxExpansions = LastExpansions = RefinementChecks = GoalSearchSkips = 0;
        InterruptedWaypoints = WaypointArrivals = RecoveryAttempts = 0;
        PlanningMilliseconds = 0;
    }

    public void Advance(ModelSensorPackage perception, CharacterController actor, bool actionCompleted)
    {
        long started = System.Diagnostics.Stopwatch.GetTimestamp();
        if (grid != perception.Grid) { Reset(); grid = perception.Grid; PlannerBuilds++; }
        sensors = perception;
        sensors.TrackSemanticObjects = true;
        position = actor.transform.position;
        clearance.Begin(grid, actor);
        LastExpansions = 0;
        try { AdvanceCore(actionCompleted); }
        finally
        {
            double elapsed = (System.Diagnostics.Stopwatch.GetTimestamp() - started) * 1000.0 /
                System.Diagnostics.Stopwatch.Frequency;
            timings.Add(elapsed); PlanningMilliseconds += elapsed;
            RefinementChecks += LastQueries;
            MaxQueries = Math.Max(MaxQueries, LastQueries);
            MaxExpansions = Math.Max(MaxExpansions, LastExpansions);
        }
    }

    private void AdvanceCore(bool completed)
    {
        if (visits.Count == 0 || Distance(position, visits[visits.Count - 1]) >= 0.5f) visits.Add(position);
        while (discoveryCursor < grid.Discoveries.Count)
        {
            Vector2Int changed = grid.Discoveries[discoveryCursor++];
            RefreshFrontier(changed); RefreshFrontier(changed + Vector2Int.left); RefreshFrontier(changed + Vector2Int.right);
            RefreshFrontier(changed + Vector2Int.up); RefreshFrontier(changed + Vector2Int.down);
        }
        RememberExit();
        if (stalledBearings.Count > 0 && Distance(position, stallPosition) >= 1.5f) stalledBearings.Clear();
        if (Mathf.Abs(clearance.Radius - lastRadius) > 0.0001f)
        {
            lastRadius = clearance.Radius; failedExit = failedFrontier = null;
            choices.Clear(); rejected.Clear(); triedFrontiers.Clear(); search = null;
        }
        if (rejected.Count > 0 && Distance(position, rejectionOrigin) >= 1f) rejected.Clear();
        if (objectVersion != sensors.Memory.Version || wallCount != grid.DiscoveredWallCellCount)
        {
            // A previously rejected transition can be reconsidered after obstacle evidence changes.
            rejected.Clear(); choices.Clear();
            objectVersion = sensors.Memory.Version; wallCount = grid.DiscoveredWallCellCount;
        }
        if (HasWaypoint)
        {
            float remaining = Distance(position, Waypoint);
            if (remaining <= tolerance) EndLeg(true, "waypoint_arrived");
            else if (remaining > Range + 0.001f || !clearance.TryLeg(Waypoint, false, out _)) FailLeg("segment_invalid");
            else if (completed)
            {
                if (bestDistance - remaining >= 0.05f) { bestDistance = remaining; stalled = 0; }
                else if (++stalled >= 20) FailLeg("progress_stalled");
            }
        }

        if (repositionNeeded)
        {
            repositionNeeded = false;
            if (TryReposition()) return;
            // In a one-way passage there may be no distinct recovery direction.
            stalledBearings.Clear(); failedExit = failedFrontier = null;
        }
        if (HasWaypoint && leg == Leg.Retreat && stalledBearings.Count > 0)
        {
            if (search != null) AdvanceSearch();
            return;
        }
        // Replace an active exploration leg only after certifying the new exit instruction.
        if (knowsExit && (!HasWaypoint || !IsExitLeg(leg)) && TryDirectExit()) return;
        if (HasWaypoint && IsExitLeg(leg) && search == null) return;
        if (routeIndex < mapRoute.Count && (!HasWaypoint || routePurpose == Leg.MapExit && !IsExitLeg(leg)) &&
            TryRouteLeg(routePurpose)) return;
        if (knowsExit && search == null && routeIndex >= mapRoute.Count && !FailedHere(true))
            StartSearch(true);
        if (search != null) AdvanceSearch();
        if (HasWaypoint || clearance.OriginBlocked) { if (!HasWaypoint) Status = "origin_blocked"; return; }
        if (routeIndex < mapRoute.Count && LastQueries + 3 > QaWaypointClearance.Budget)
        {
            Status = "checking_route_legs"; return;
        }

        if (FailedHere(false) && search == null)
        {
            GoalSearchSkips++; Status = "observed_space_exhausted"; return;
        }
        if (TryExplore()) return;
        if (clearance.OriginBlocked) { Status = "origin_blocked"; return; }
        if (choiceIndex < choices.Count) { Status = "checking_local_legs"; return; }
        Vector2Int? nearest = NearestFrontier();
        if (nearest.HasValue && TryFrontierApproach(nearest.Value)) return;
        if (search == null && !FailedHere(false))
        {
            if (nearest.HasValue)
            {
                StartSearch(false, nearest.Value);
                if (LastExpansions == 0) AdvanceSearch();
            }
            else failedFrontier = Here;
        }
        if (HasWaypoint) return;
        if (!usedRetreat && TryRetreat()) return;
        Status = clearance.OriginBlocked ? "origin_blocked" :
            search != null ? SearchPhase : "observed_space_exhausted";
    }

    private void RefreshFrontier(Vector2Int cell)
    {
        ModelMapCell value = grid.ReadCell(cell);
        bool boundary = value.Observed && !value.Wall &&
            (!grid.ReadCell(cell + Vector2Int.left).Observed || !grid.ReadCell(cell + Vector2Int.right).Observed ||
             !grid.ReadCell(cell + Vector2Int.up).Observed || !grid.ReadCell(cell + Vector2Int.down).Observed);
        if (boundary) frontiers.Add(cell); else frontiers.Remove(cell);
        triedFrontiers.Remove(cell);
    }

    private void RememberExit()
    {
        // A trigger between two rays is still a legitimate line-of-sight semantic discovery.
        QaDiscoveryMemory.Record nearest = null;
        foreach (QaDiscoveryMemory.Record record in sensors.Memory.Records)
        {
            if (record.Kind != QaDiscoveryKind.Exit) continue;
            if (knowsExit && HasWaypoint && IsExitLeg(leg) && record.Bounds == exitBounds) return;
            if (nearest == null || Distance(record.Position, position) < Distance(nearest.Position, position))
                nearest = record;
        }
        if (nearest != null)
        {
            if (!knowsExit || nearest.Bounds != exitBounds)
            {
                exitBounds = nearest.Bounds; knowsExit = true; search = null; failedExit = null;
            }
            return;
        }
        // Legacy exit markers can be ray-only. Grid.ExitDiscoveryVersion tracks new hit cells.
        if (rayExitJournal == grid.ExitDiscoveryVersion) return;
        rayExitJournal = grid.ExitDiscoveryVersion;
        foreach (ModelSensorTrace trace in sensors.Traces)
            if (trace.HitId == QaObjectType.LevelEnd)
            {
                exitBounds = new Bounds(trace.Endpoint, Vector3.one * ModelSensorGrid.CellSize);
                knowsExit = true; failedExit = null; return;
            }
    }

    private bool TryDirectExit()
    {
        Vector3 target = exitBounds.center;
        target.y = position.y;
        Vector3 delta = target - position;
        Vector3 request = position + Vector3.ClampMagnitude(delta, Range);
        if (!clearance.TryLeg(request, true, out Vector3 point)) return false;
        float length = Distance(position, point);
        // Approaching an observed edge of the trigger is enough to actuate it in Unity.
        bool atTrigger = Distance(point, exitBounds.ClosestPoint(point)) < 0.08f;
        if (!atTrigger && (length < 0.6f || length < Distance(position, request) * 0.85f)) return false;
        if (length < 0.035f || !CanIssue(point)) return false;
        mapRoute.Clear(); routeIndex = 0; search = null;
        Publish(point, Leg.Exit, "exit_assigned");
        return true;
    }

    private void EndLeg(bool arrived, string reason)
    {
        if (leg == Leg.Retreat && (arrived || reason == "segment_invalid"))
        {
            // Re-anchor unfinished frontier work when recovery lands beyond its old starting cell.
            // Any usable route already in hand still takes priority from the new position.
            if (arrived && search != null && !search.ForExit && routeIndex >= mapRoute.Count &&
                searchOrigin.HasValue && searchOrigin.Value.cell != ModelSensorGrid.WorldToCell(position))
            {
                search = null;
                DiagnosticEvent?.Invoke("frontier_search_reanchored");
            }
            // Arrival can fall just inside the distance used for ongoing recovery. A completed
            // reposition always gets a fresh assessment from its actual new viewing angle.
            stalledBearings.Clear(); rejected.Clear(); failedFrontier = failedExit = null;
        }
        if (approachedFrontier.HasValue && arrived) triedFrontiers.Add(approachedFrontier.Value);
        approachedFrontier = null;
        HasWaypoint = false;
        if (arrived) WaypointArrivals++; else InterruptedWaypoints++;
        DiagnosticEvent?.Invoke(reason);
        choices.Clear(); choiceIndex = 0; Route.Clear();
    }

    private void FailLeg(string reason)
    {
        RejectApproach(Waypoint);
        if (reason == "progress_stalled")
        {
            if (stalledBearings.Count == 0) stallPosition = position;
            Vector3 delta = Waypoint - position; delta.y = 0f;
            stalledBearings.Add(delta.normalized); repositionNeeded = true;
        }
        // A provisional leg can fail while its complete route is still being computed or held.
        if (!issuedPrefix || mapRouteIsPrefix) { mapRoute.Clear(); routeIndex = 0; }
        if (!issuedPrefix) search = null;
        Replans++; AbandonedGoals++; failedExit = failedFrontier = null;
        EndLeg(false, reason);
    }

    private void RejectApproach(Vector3 target)
    {
        // A failed approach from here does not disqualify the same point from a different side.
        if (rejected.Count == 0) rejectionOrigin = position;
        rejected.Add(ModelSensorGrid.WorldToCell(target));
    }

    private bool CanIssue(Vector3 target)
    {
        if (rejected.Contains(ModelSensorGrid.WorldToCell(target))) return false;
        Vector3 direction = target - position; direction.y = 0f; direction.Normalize();
        foreach (Vector3 bearing in stalledBearings)
            if (Vector3.Dot(bearing, direction) > 0.8f) return false;
        return true;
    }

    private void Publish(Vector3 target, Leg purpose, string reason)
    {
        if (HasWaypoint) EndLeg(false, IsExitLeg(purpose) ? "exit_route_ready" : "map_route_ready");
        float distance = Distance(position, target);
        Waypoint = target; HasWaypoint = true; WaypointVersion++;
        leg = purpose; bestDistance = distance; stalled = 0;
        issuedPrefix = mapRouteIsPrefix && (purpose == Leg.MapExit || purpose == Leg.MapFrontier);
        tolerance = Mathf.Clamp(distance * 0.18f, 0.045f, 0.32f);
        if (purpose == Leg.Exit) tolerance = 0.06f;
        if (purpose != Leg.Retreat)
        {
            usedRetreat = false;
            heading = (target - position).normalized;
        }
        Status = IsExitLeg(purpose) ? "exit" : purpose == Leg.Retreat ? "recovering" : "exploring";
        Route.Clear(); Route.Add(target);
        if (purpose == Leg.MapExit || purpose == Leg.MapFrontier)
            for (int i = routeIndex; i < mapRoute.Count; i++) Route.Add(mapRoute[i]);
        choices.Clear(); choiceIndex = 0;
        DiagnosticEvent?.Invoke(reason);
    }

    private float VisitDistance(Vector3 point)
    {
        float best = (point - position).sqrMagnitude;
        foreach (Vector3 visit in visits)
        {
            float x = point.x - visit.x, z = point.z - visit.z;
            best = Mathf.Min(best, x * x + z * z);
        }
        return Mathf.Sqrt(best);
    }

    private bool FreshFrontier(Vector3 point)
    {
        // In a bend, a neighbouring quarter-cell may be the only new vantage point.
        Vector2Int cell = ModelSensorGrid.WorldToCell(point);
        return !triedFrontiers.Contains(cell) && !grid.ReadCell(cell).Visited && VisitDistance(point) >= MinStep;
    }

    private void RankSightlines()
    {
        GoalSelections++; choiceIndex = 0; choices.Clear(); choicesOrigin = Here;
        ModelSensorTrace[] rays = sensors.Traces;
        // A maximum-range ray can cross an entirely mapped room. Require actual boundary evidence
        // in this angular sector, including the end of the ray and the mouths of narrow passages.
        for (int i = 0; i < rays.Length; i++)
        {
            Vector3 delta = rays[i].Endpoint - rays[i].Origin; delta.y = 0f;
            float length = delta.magnitude;
            Vector3 direction = delta.normalized;
            int count = 0;
            for (float d = 0.25f; d < length; d += 0.5f)
                if (frontiers.Contains(ModelSensorGrid.WorldToCell(position + d * direction))) count++;
            if (frontiers.Contains(ModelSensorGrid.WorldToCell(rays[i].Endpoint))) count++;
            visibleFrontiers[i] = count;
        }
        for (int i = 0; i < rays.Length; i++)
        {
            Vector3 delta = rays[i].Endpoint - rays[i].Origin; delta.y = 0f;
            float rayLength = delta.magnitude;
            if (rayLength <= MinStep) continue;
            Vector3 direction = delta / rayLength;
            float distance = Mathf.Min(Range, rayLength);
            if (rays[i].HitId == QaObjectType.Wall) distance = Mathf.Min(distance, rayLength - clearance.Radius - 0.10f);
            if (distance < MinStep) continue;
            Vector3 point = position + distance * direction;
            float novelty = VisitDistance(point);
            if (novelty < MinStep || rejected.Contains(ModelSensorGrid.WorldToCell(point))) continue;
            // A wide visible sector has room for the learned controller's lateral movement.
            int left = (i + rays.Length - 2) % rays.Length, right = (i + 2) % rays.Length;
            float width = Mathf.Min(Distance(rays[left].Origin, rays[left].Endpoint),
                Distance(rays[right].Origin, rays[right].Endpoint));
            int frontierSamples = visibleFrontiers[i];
            for (int offset = -2; offset <= 2; offset++)
                frontierSamples = Mathf.Max(frontierSamples, visibleFrontiers[(i + offset + rays.Length) % rays.Length]);
            if (frontierSamples == 0) continue;
            float score = 2f * novelty + 0.25f * distance + 0.15f * Mathf.Min(width, distance) +
                0.6f * Vector3.Dot(direction, heading) + 0.12f * Mathf.Min(frontierSamples, 8);
            if (knowsExit) score += Distance(position, exitBounds.center) - Distance(point, exitBounds.center);
            choices.Add(new RayChoice(point, score, i));
        }
        choices.Sort((a, b) =>
        {
            int order = b.Score.CompareTo(a.Score);
            return order == 0 ? a.Index.CompareTo(b.Index) : order;
        });
    }

    private bool TryExplore()
    {
        if (choices.Count == 0 || !choicesOrigin.HasValue || !choicesOrigin.Value.Equals(Here)) RankSightlines();
        while (choiceIndex < choices.Count && LastQueries + 3 <= QaWaypointClearance.Budget)
        {
            Vector3 request = choices[choiceIndex++].Point;
            if (!clearance.TryLeg(request, true, out Vector3 point))
            { if (clearance.OriginBlocked) break; continue; }
            float distance = Distance(position, point);
            if (distance < MinStep || VisitDistance(point) < MinStep || !CanIssue(point)) continue;
            // An oblique ray can clip a wall long before its endpoint. Prefer a full, useful leg.
            if (distance < 0.55f * Distance(position, request)) continue;
            if (VisitDistance(point) < 0.65f && !FreshFrontier(point)) continue;
            Publish(point, Leg.Explore, "sightline_assigned");
            return true;
        }
        return false;
    }

    private Vector2Int? NearestFrontier()
    {
        Vector2Int? nearest = null;
        float best = float.PositiveInfinity;
        foreach (Vector2Int cell in frontiers)
        {
            Vector3 point = QaObservedRoutePlanner.Point(cell, position.y);
            float distance = (point - position).sqrMagnitude;
            if (distance > best || rejected.Contains(cell) || !FreshFrontier(point)) continue;
            if (distance == best && nearest.HasValue &&
                (cell.x > nearest.Value.x || cell.x == nearest.Value.x && cell.y >= nearest.Value.y)) continue;
            nearest = cell; best = distance;
        }
        return nearest;
    }

    private bool TryFrontierApproach(Vector2Int nearest)
    {
        Vector3 target = QaObservedRoutePlanner.Point(nearest, position.y);
        Vector3 request = position + Vector3.ClampMagnitude(target - position, Range);
        if (!clearance.TryLeg(request, true, out Vector3 approach)) return false;
        float length = Distance(position, approach);
        if (length < MinStep || length < 0.8f * Distance(position, request) || !CanIssue(approach)) return false;
        Publish(approach, Leg.Explore, "frontier_approach_assigned");
        if (Distance(approach, target) < 0.35f) approachedFrontier = nearest;
        return true;
    }

    private bool FailedHere(bool forExit)
    {
        var failure = forExit ? failedExit : failedFrontier;
        return failure.HasValue && failure.Value.Equals(Here);
    }

    private void StartSearch(bool forExit, Vector2Int preferred = default)
    {
        if (forExit) preferred = ModelSensorGrid.WorldToCell(exitBounds.center);
        search = new QaWaypointMapSearch(grid, position, forExit, exitBounds, preferred, rejected.Contains, FreshFrontier);
        RouteSearches++; searchOrigin = Here;
    }

    private void AdvanceSearch()
    {
        search.Advance();
        LastExpansions += search.LastExpansions;
        if (!search.Finished)
        {
            if (!HasWaypoint && routeIndex >= mapRoute.Count && search.TryCopyPrefix(mapRoute))
            {
                PrepareMapRoute(search.ForExit, true);
                TryRouteLeg(routePurpose);
            }
            return;
        }
        var finished = search; search = null;
        if (finished.Path.Count > 0)
        {
            mapRoute.Clear(); mapRoute.AddRange(finished.Path);
            PrepareMapRoute(finished.ForExit, false);
            if (HasWaypoint && (!finished.ForExit || IsExitLeg(leg) || leg == Leg.Retreat && stalledBearings.Count > 0)) return;
            if (TryRouteLeg(routePurpose) || routeIndex < mapRoute.Count) return;
        }
        if (finished.ForExit) failedExit = searchOrigin; else failedFrontier = searchOrigin;
        DiagnosticEvent?.Invoke(finished.ForExit ? "exit_route_unavailable" : "frontier_route_unavailable");
    }

    private void PrepareMapRoute(bool forExit, bool prefix)
    {
        routePurpose = forExit ? Leg.MapExit : Leg.MapFrontier;
        mapRouteIsPrefix = prefix;
        routeIndex = 0;
        float best = float.PositiveInfinity;
        for (int i = 0; i < mapRoute.Count; i++)
        {
            float distance = (mapRoute[i] - position).sqrMagnitude;
            if (distance <= best) { best = distance; routeIndex = i; }
        }
        routeScan = routeIndex;
    }

    private bool TryRouteLeg(Leg purpose)
    {
        // Re-anchor a completed search to the current body. Only publish a usable, visible prefix.
        int selected = -1;
        for (int i = Mathf.Max(routeIndex, routeScan); i < mapRoute.Count; i++)
        {
            float distance = Distance(position, mapRoute[i]);
            if (distance > Range) { if (selected >= 0) break; continue; }
            if (distance < MinStep || !CanIssue(mapRoute[i])) continue;
            if (LastQueries + 3 > QaWaypointClearance.Budget)
            {
                if (selected < 0) { routeScan = i; return false; }
                break;
            }
            if (!clearance.TryLeg(mapRoute[i], false, out _)) { if (selected >= 0) break; continue; }
            selected = i;
        }
        if (selected >= 0)
        {
            routeIndex = routeScan = selected + 1;
            Publish(mapRoute[selected], purpose, mapRouteIsPrefix ? "route_prefix_assigned" : "map_leg_assigned");
            if (!mapRouteIsPrefix && purpose == Leg.MapFrontier && routeIndex == mapRoute.Count)
                approachedFrontier = ModelSensorGrid.WorldToCell(mapRoute[selected]);
            return true;
        }
        if (routeIndex < mapRoute.Count) RejectApproach(mapRoute[routeIndex]);
        mapRoute.Clear(); routeIndex = 0;
        return false;
    }

    private bool TryReposition()
    {
        if (recentRepositions.Count == 0 || Distance(position, repositionOrigin) > 2f)
        { recentRepositions.Clear(); repositionOrigin = position; }
        var alternatives = new List<RayChoice>();
        ModelSensorTrace[] rays = sensors.Traces;
        for (int i = visits.Count - 1; i >= 0; i--)
        {
            float distance = Distance(position, visits[i]);
            if (distance >= 2f && distance <= Mathf.Min(4f, Range))
                AddReposition(alternatives, visits[i], rays.Length + i, true);
        }
        for (int i = 0; i < rays.Length; i++)
        {
            Vector3 delta = rays[i].Endpoint - rays[i].Origin; delta.y = 0f;
            float length = Mathf.Min(4f, Mathf.Min(Range, delta.magnitude - clearance.Radius - 0.1f));
            if (length >= 0.65f) AddReposition(alternatives, position + delta.normalized * length, i, false);
        }
        alternatives.Sort((a,b) => a.Score == b.Score ? a.Index.CompareTo(b.Index) : b.Score.CompareTo(a.Score));
        foreach (RayChoice choice in alternatives)
        {
            if (LastQueries + 3 > QaWaypointClearance.Budget) break;
            if (!clearance.TryLeg(choice.Point, !choice.Visited, out Vector3 point) || !CanIssue(point) ||
                Distance(position, point) < Mathf.Max(0.65f, 0.7f * Distance(position, choice.Point)))
                continue;
            recentRepositions.Add(point);
            if (recentRepositions.Count > 3) recentRepositions.RemoveAt(0);
            usedRetreat = true; RecoveryAttempts++;
            Publish(point, Leg.Retreat, choice.Visited ? "visited_retreat_assigned" : "stall_reposition_assigned");
            return true;
        }
        return false;
    }

    private void AddReposition(List<RayChoice> choicesToScore, Vector3 point, int index, bool visited)
    {
        if (!CanIssue(point)) return;
        // Prefer space away from observed wall surfaces. A prior position wins a close tie.
        float wallDistance = 4f;
        foreach (ModelSensorTrace ray in sensors.Traces)
            if (ray.HitId == QaObjectType.Wall) wallDistance = Mathf.Min(wallDistance, Distance(point, ray.Endpoint));
        Vector3 direction = (point - position).normalized;
        float turn = Mathf.Abs(Vector3.Dot(stalledBearings[stalledBearings.Count - 1], direction));
        float score = 2f * wallDistance + 0.25f * Distance(position, point) - turn;
        if (visited) score += 0.4f;
        foreach (Vector3 previous in recentRepositions)
            if (Distance(point, previous) < 1.25f) { score -= 4f; break; }
        choicesToScore.Add(new RayChoice(point, score, index, visited));
    }

    private bool TryRetreat()
    {
        for (int i = visits.Count - 1; i >= 0 && LastQueries + 3 <= QaWaypointClearance.Budget; i--)
        {
            float distance = Distance(position, visits[i]);
            if (distance < 0.7f || distance > Mathf.Min(4f, Range) || !CanIssue(visits[i])) continue;
            if (!clearance.TryLeg(visits[i], false, out Vector3 point)) continue;
            usedRetreat = true; RecoveryAttempts++;
            Publish(point, Leg.Retreat, "visited_retreat_assigned");
            return true;
        }
        return false;
    }
}
