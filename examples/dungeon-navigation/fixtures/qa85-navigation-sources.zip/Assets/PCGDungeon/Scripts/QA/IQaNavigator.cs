using System;
using System.Collections.Generic;
using UnityEngine;

// Shared waypoint contract; counters below are evaluation diagnostics, not policy inputs.
public interface IQaNavigator
{
    void Reset();
    void Advance(ModelSensorPackage sensors, CharacterController actor, bool actionCompleted);
    bool HasWaypoint { get; }
    Vector3 Waypoint { get; }
    int WaypointVersion { get; }
    string Status { get; }
    float MaxWaypointDistance { get; set; }
    bool HasGoal { get; }
    bool GoalIsExit { get; }
    Vector2Int GoalCell { get; }
    List<Vector3> Route { get; }
    event Action<string> DiagnosticEvent;
    int Replans { get; }
    int AbandonedGoals { get; }
    int PlannerBuilds { get; }
    int GoalSelections { get; }
    int RouteSearches { get; }
    int GoalSearchSkips { get; }
    int RefinementChecks { get; }
    int RefinedCells { get; }
    int ExcludedCount { get; }
    Vector3[] ExcludedFrontiers { get; }
    double PlanningMilliseconds { get; }
    QaObservedRoutePlanner PlannerSnapshot { get; }
}

public interface IQaMeasuredNavigator : IQaNavigator
{
    IReadOnlyList<double> Timings { get; }
    int MaxExpansions { get; }
    int MaxQueries { get; }
    int InterruptedWaypoints { get; }
    int WaypointArrivals { get; }
    int RecoveryAttempts { get; }
}
