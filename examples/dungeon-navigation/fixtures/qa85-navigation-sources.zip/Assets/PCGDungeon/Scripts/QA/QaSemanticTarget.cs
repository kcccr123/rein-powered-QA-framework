using UnityEngine;

public enum QaDiscoveryKind { Exit, Key, Chest, Door, Loot, Switch }

// Optional semantic annotation. It does not change the historical policy ray IDs.
[DisallowMultipleComponent]
public sealed class QaSemanticTarget : MonoBehaviour
{
    public QaDiscoveryKind kind;
    public string state = "available";
    public bool blocksNavigation;
}
