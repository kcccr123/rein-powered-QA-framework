using System.Collections.Generic;
using UnityEngine;

public sealed class QaDiscoveryMemory
{
    public sealed class Record
    {
        public int Id;
        public QaDiscoveryKind Kind;
        public Vector3 Position;
        public string State;
        public float ObservedAt;
        public Bounds Bounds;
    }

    private readonly Dictionary<int, Record> records = new Dictionary<int, Record>();
    public IEnumerable<Record> Records => records.Values;
    public int Count => records.Count;
    public int ExitVersion { get; private set; }
    public int Version { get; private set; }
    public void Reset() { records.Clear(); ExitVersion = Version = 0; }

    public void Observe(Component target, QaDiscoveryKind kind, Vector3 position, string state, Bounds bounds)
    {
        int id = target.GetInstanceID();
        if (!records.TryGetValue(id, out Record record))
        {
            record = new Record { Id = id, Kind = kind };
            records.Add(id, record);
            Version++;
            if (kind == QaDiscoveryKind.Exit) ExitVersion++;
        }
        else if (kind == QaDiscoveryKind.Exit && (record.Position - position).sqrMagnitude > 0.0001f)
            ExitVersion++;
        if (record.State != state || (record.Position - position).sqrMagnitude > 0.0001f) Version++;
        record.Position = position;
        record.State = state;
        record.ObservedAt = Time.fixedTime;
        record.Bounds = bounds;
    }
}
